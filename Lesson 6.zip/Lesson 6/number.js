
//declare the variables 
//we prompt the user to enter the number
//and then we check weatcher the guess is right or wrong


// Rule 1: control variable 

var count;

//loop, prompt user to enter a number untill its correct

do{
    
    //asking for the number from user
    //Satisfying rule 3
    count = prompt("Enter a number between 1 and 10");
    
}while (count != 4);//Rule 2: Using control variable in the condition 
document.write("<h1> You guessed correctly!<h1>");